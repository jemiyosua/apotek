import Header from './Header';
import Footer from './Footer';
import SlideShow from './SlideShow';
// import Pagination from './Pagination';

export {Header, Footer, SlideShow};
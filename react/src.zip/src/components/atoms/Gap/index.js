import React from 'react'

function Gap({width,height}) {
    return (
        <div style={{width,height}}/>
    )
}

export default Gap

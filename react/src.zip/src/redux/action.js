export const setForm =(inputType,value)=> {
    return {type: 'SET_FORM',inputType:inputType,inputValue:value};
}
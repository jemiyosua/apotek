import Header from './Header';
import HeaderPage from './HeaderPage';
// import Pagination from './Pagination';

export { Header, HeaderPage };
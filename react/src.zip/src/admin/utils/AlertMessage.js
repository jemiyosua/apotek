export const AlertMessage = {
    failedConnect: "Saat ini tidak dapat terhubung dengan server Starpoin. Silahkan cek jaringan anda dan coba kembali.",
    failedFecthTooBig: "Permintaan tidak dapat diselesaikan karena proses melebihi batas waktu. Mohon ulangi dengan rentang tanggal yang lebih singkat."
};
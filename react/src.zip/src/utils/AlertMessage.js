export const AlertMessage = {
    failedConnect:"Saat ini tidak dapat terhubung dengan server Simas Insurtech. Silahkan cek jaringan anda dan coba kembali."
};
export const paths ={
    // URL_API:"http://appdev.starpoin.id:1000/api/admin/v1/",
    // URL_API_STATIC:"http://appdev.starpoin.id:1000/api/v2/static/",
    // URL_API_DYNAMIC:"http://appdev.starpoin.id:1000/api/v2/static/",
    // ENCKEY_API:process.env.REACT_APP_ENCKEY
    URL_API:process.env.REACT_APP_URL_API,
    URL_API_STATIC:process.env.REACT_APP_URL_API_STATIC,
    URL_API_DYNAMIC:process.env.REACT_APP_URL_API_DYNAMIC,
    ENCKEY_API:process.env.REACT_APP_ENCKEY
}


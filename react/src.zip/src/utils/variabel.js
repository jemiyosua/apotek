var IncludeCSS = '<!DOCTYPE html><html><head><style>';
IncludeCSS = IncludeCSS +'.divMaxWidth02 {width:90%;clear:both;}';
IncludeCSS = IncludeCSS +'.imgHeader {left:0px;top:10px;}';
IncludeCSS = IncludeCSS +'.imgBody {background:url("https://apivoucher.starpoin.id/images/side-pic-1.jpg") top right no-repeat;opacity:0.3!important;z-index:-999;}';
IncludeCSS = IncludeCSS +'.div01 {clear:both;text-align:left;color:#424543;}';
IncludeCSS = IncludeCSS +'@media (min-width: 800px) {';
IncludeCSS = IncludeCSS +'.imgHeader {max-width:100%;}';
IncludeCSS = IncludeCSS +'.divMaxWidth01 { margin : 10px auto; width:486px;height:328px;}';
IncludeCSS = IncludeCSS +'.imgBody {background-size:167px 179px; height:179px;}';
IncludeCSS = IncludeCSS +'.div01 {width:486px;font-size: 14px;}}';
IncludeCSS = IncludeCSS +'@media (max-width: 799px) {';
IncludeCSS = IncludeCSS +'.imgHeader {max-width:80%;}';
IncludeCSS = IncludeCSS +'.divMaxWidth01 { margin : 10px auto; width:90vw;height:290px;}';
IncludeCSS = IncludeCSS +'.imgBody {background-size:80px 160px;height:140px;}';
IncludeCSS = IncludeCSS +'.left {font-size: 13px;}';
IncludeCSS = IncludeCSS +'.div01 {font-size: 12px;width:90vw; overflow:auto;}}';
IncludeCSS = IncludeCSS +'.center{margin-left:auto;margin-right:auto;max-width:500px;text-align: center;}';
IncludeCSS = IncludeCSS +'.banner{width: 100%;max-width: 700px;min-width: 300px;}';
IncludeCSS = IncludeCSS +'</style></head><body style="word-wrap: break-word;-webkit-nbsp-mode: space;line-break: after-white-space;max-width:100%">';
const IncludeCSS2 = '</body></html>';

export var variabel = {
    IncludeCSS:IncludeCSS,
    IncludeCSS2:IncludeCSS2
};